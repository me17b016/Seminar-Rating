package com.example.mysecondberkley

import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.core.Context
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*

class Login : AppCompatActivity() {
    lateinit var token : SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        token = getSharedPreferences("user", android.content.Context.MODE_PRIVATE)
        signin_progress.visibility = View.INVISIBLE
        if (token.getString("loginId", " ") != " ") {
            if (token.getString("loginId", " ") == "admin123@iittp.ac.in") {
                val intent = Intent(this, admin::class.java)
                startActivity(intent)
                finish()
            }
            else {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
    fun signInUser (view: View) {
        val email = etsignEmail.text.toString()
        val password = etsignPassword.text.toString()
        if (email.isEmpty()) {
            Toast.makeText(this, "Email is required", Toast.LENGTH_SHORT).show()
            return
        }
        if (password.isEmpty()) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show()
            return
        }
        btRegisterHere.isEnabled = false;
        bLogin.isEnabled = false
        signin_progress.visibility = View.VISIBLE
        var editor = token.edit()
        editor.putString("loginId", email)
        editor.commit()
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                signin_progress.visibility = View.INVISIBLE
                if (it.isSuccessful) {
                    //Log.d("login", "working")
                    Toast.makeText(this, "Successfully signed in", Toast.LENGTH_SHORT).show()
                    if (email == "admin123@iittp.ac.in") {
                        val intent = Intent(this, admin::class.java)
                        startActivity(intent)
                        finish()
                    }
                    else {
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                   // return@addOnCompleteListener
                }
                else {
                    btRegisterHere.isEnabled = true
                    bLogin.isEnabled = true

                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Please check your username and password", Toast.LENGTH_SHORT).show()
            }
    }
    fun changeToRegister(view : View) {
        val intent = Intent(this, Register::class.java)
        startActivity(intent)
        finish()
    }
}
