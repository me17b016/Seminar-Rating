package com.example.mysecondberkley

class User (val Id : String, val user: String, val rating: Float)