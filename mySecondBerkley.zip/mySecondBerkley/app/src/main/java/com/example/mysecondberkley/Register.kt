package com.example.mysecondberkley

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_register.*

class Register : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        reg_progress.visibility = View.INVISIBLE
    }
    fun backToSignIn(view: View) {
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
        finish()
    }
    fun registerUser(view : View) {
        val email = etEmail.text.toString()
        val password = etPassword.text.toString()
        if (email.isEmpty()) {
            etEmail.error = "enter your mail"
            Toast.makeText(this, "Email is required", Toast.LENGTH_SHORT).show()
            return
        }
        if (password.isEmpty()) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show()
            return
        }
        reg_progress.visibility = View.VISIBLE
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener {
                reg_progress.visibility = View.INVISIBLE
                if (it.isSuccessful) {
                    Toast.makeText(this, "Successfully Registered", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, Login::class.java)
                    startActivity(intent)
                    finish()
                    return@addOnCompleteListener
                }
            }
            .addOnFailureListener{
                Toast.makeText(this, "Failed Registeration ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
