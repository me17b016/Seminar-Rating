package com.example.mysecondberkley

class NodeStatus(var stat : String, var value : Boolean)