package com.example.mysecondberkley

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_admin.*
import java.util.*

class admin : AppCompatActivity() {
    var status = false
    var curr_grp : Int = 0
    var total : Float = 0.0f
    var  number: Float = 0.0f
    lateinit var token : SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        token = getSharedPreferences("user", Context.MODE_PRIVATE)
    }
    fun changeToLog(view : View) {
        FirebaseAuth.getInstance().signOut()
        var editor = token.edit();
        editor.putString("loginId", " ")
        editor.commit()
        //val login = findViewById<Button>(R.id.bLogout)
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
        finish()
    }

    fun Enable(view: View) {
        if (bEnable.text == "Enable") {
            bEnable.text = "Disable"
            status = true
            curr_grp = etAdmin_value.text.toString().toInt()
            var node = NodeStatus("${etAdmin_value.text}", true)
            FirebaseDatabase.getInstance().getReference("Enable")
                .child("admin").setValue(node)
            //val intent = Intent(this, MainActivity::class.java)
            //startActivity(intent)
            //finish()
        }
        else {
            bEnable.text = "Enable"
            var node = NodeStatus("${etAdmin_value.text}", false)
            FirebaseDatabase.getInstance().getReference("Enable")
                .child("admin").setValue(node).addOnCompleteListener{
                    if (it.isSuccessful) {
                        FirebaseDatabase.getInstance().getReference("${curr_grp}").addValueEventListener(object : ValueEventListener {
                            override fun onCancelled(p0: DatabaseError) {
                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                            }

                            override fun onDataChange(p0: DataSnapshot) {
                                if (p0!!.exists()) {
                                    total = 0.0f
                                    number = 0.0f
                                    for (e in p0.children) {
                                        total += e.child("rating").getValue(Float::class.java)!!
                                        Log.d("mp", "${total}")
                                        number++
                                        val tem = total / number
                                        tvRating_value.text = tem.toString()
                                    }
                                }

                            }

                        })
                        //Toast.makeText(this@admin, "your rating is ${total/number}", Toast.LENGTH_LONG).show()
                    }
                }
        }
    }
}
