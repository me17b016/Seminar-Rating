package com.example.mysecondberkley

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(){
    var total : Float = 0.0f
    var  number: Float = 0.0f
    var grp : String = ""
    var stat = false
    lateinit var token : SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        token = getSharedPreferences("user", Context.MODE_PRIVATE)
        check()
    }

    fun check() {
        FirebaseDatabase.getInstance().getReference("Enable").addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0.exists()) {
                    for (e in p0.children) {
                        if (e.child("value").getValue(Boolean::class.java)!!) {
                            stat = true
                            grp = e.child("stat").getValue(String()::class.java)!!
                            main_submit.isEnabled = true
                        }
                    }
                }
            }
        })
    }
    fun submitRating(view: View) {
        main_submit.isEnabled = false
        val database = FirebaseDatabase.getInstance()
        var ne_node = grp
        val myRef = database.getReference("${ne_node}")
        val id = myRef.push().key
        val node = User(id!!,"raj", main_rating.rating.toFloat())
        myRef.child(id).setValue(node)
        Toast.makeText(this, "your rating is ${main_rating.rating.toFloat()}", Toast.LENGTH_SHORT).show()
        /*FirebaseDatabase.getInstance().getReference("${ne_node}").addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0!!.exists()) {
                    total = 0.0f
                    number = 0.0f
                    for (e in p0.children) {
                        total += e.child("rating").getValue(Float::class.java)!!
                        Log.d("mp", "${total}")
                        number++
                    }
                }

            }

        }
        )
        Toast.makeText(this@MainActivity, "your rating is ${total/number}", Toast.LENGTH_LONG).show()
        //total = total / number*/

    }
    private fun test() {
        FirebaseDatabase.getInstance().getReference("Rating").addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0!!.exists()) {
                    total = 0.0f
                    number = 0.0f
                    for (e in p0.children) {

                        // val user = e.getValue() as HashMap<String, Float>
                        //Log.d("total", "${e.getValue(User::class.java)!!}")
                        //Log.d("total", "${node.rating}")
                        //total += node.rating
                        // total += user.get("rating") as Float
                        total += e.child("rating").getValue(Float::class.java)!!
                        Log.d("mp", "${total}")
                        number++
                    }
                    Toast.makeText(this@MainActivity, "hii", Toast.LENGTH_SHORT).show()
                }

            }


        })
        Toast.makeText(this@MainActivity, "your rating is ${total/number}", Toast.LENGTH_LONG).show()
    }
    fun changeToLogin(view : View) {
        FirebaseAuth.getInstance().signOut()
        var editor = token.edit();
        editor.putString("loginId", " ")
        editor.commit()
        //val login = findViewById<Button>(R.id.bLogout)
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
        finish()
    }
}
